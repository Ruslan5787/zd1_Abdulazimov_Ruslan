﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cat
{
    class Program
    {
        static void Main (string [ ] args)
        {
            Cat tima = new Cat("Тима", 10);
            Cat murzik = new Cat("Барсег", 22);

            tima.Meow( );
            murzik.Meow( );

            murzik.Name = "Барсик";
            murzik.Meow( );
            murzik.Name = "1234";
            murzik.Meow( );

            murzik.Weight = -10;

            murzik.getWeight( );

            Console.ReadKey( );
        }
    }
}
