﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cat
{
    class Cat
    {
        private string name;
        private double weight;

        public Cat (string catName)
        {
            Name = catName;
        }

        public Cat (string catName, double weight)
        {
            Name = catName;
            Weight = weight;
        }

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                bool onlyLetters = true;

                foreach (var ch in value)
                {
                    if ( !char.IsLetter(ch) )
                    {
                        onlyLetters = false;
                    }
                }

                if (onlyLetters)
                {
                    name = value;
                }
                else
                {
                    Console.WriteLine($"{value} - неправильное имя!!!");
                }
            }
        }

        public double Weight
        {
            get
            {
                return weight;
            }
            set
            {
                if ( value < 1 && value < 20 )
                {
                    Console.WriteLine($"Вес должен быть больше 0 и меньше 20 кг!");
                } else
                {
                    weight = value;
                }
            }
        }

        public void Meow()
        {
            Console.WriteLine($"{name}: МЯЯЯУ!!! Вес - {weight}");
        }

        public void getWeight ()
        {
            Console.WriteLine($"Вес - {weight}");
        }
    }
}
