﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace playlist
{
    struct Song
    {
        public string Title;
        public string Author;
        public string FileName;
    }

    internal static class Program
    {
        
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());

            Playlist playlist = new Playlist();

            playlist.addSong("Звезда по имени Солнце", "Кино", "D:\\ProgramData\\Microsoft\\VisualStudio");
            
            Song song2 = new Song();

            song2.Author = "Нам с тобой";
            song2.Title = "Виктор Цой";
            song2.FileName = "C:\\$Windows.~WS\\Sources\\Panther";

            playlist.addSong(song2);

            playlist.getInfoAboutSongs();

            playlist.getInfoAboutSong(0);

            playlist.getInfoAboutSong(10);

            playlist.nextSong();
            playlist.previousSong();

            playlist.clearPlaylist();
        }
    }
}
