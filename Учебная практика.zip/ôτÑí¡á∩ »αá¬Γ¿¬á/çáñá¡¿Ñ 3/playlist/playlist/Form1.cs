﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace playlist
{
    public partial class Form1 : Form
    {
        Playlist playlist = new Playlist();

        public void playlistIsEmpty()
        {
            MessageBox.Show(
                    "В вашем плейлисте нет песен!",
                    "Ошибка",
                    MessageBoxButtons.OK);
        }

        public string checkingString(string text) {
            string message = "";

            foreach (var letter in text)
            {
                int num;

                if (!char.IsNumber(letter) || !char.IsLetter(letter))
                {
                    message = "Можно вводить только буквы и цифры!";
                }
            }

            return message;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                if(checkingString(textBox1.Text) == "" && checkingString(textBox1.Text) == "" && checkingString(textBox1.Text) == "")
                {

                    playlist.addSong(textBox1.Text, textBox2.Text, textBox3.Text);

                    listBox1.Items.Clear();

                    List<string> songsNames = new List<string>();

                    foreach (var song in playlist.playlist)
                    {
                        songsNames.Add(song.Title);
                    }

                    listBox1.Items.AddRange(songsNames.ToArray());

                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                } else
                {
                    MessageBox.Show(
                    "Можно вводить только буквы и цифры!",
                    "Ошибка",
                    MessageBoxButtons.OK);
                }
            }
            else
            {
                MessageBox.Show(
                    "Заполните пустые поля!",
                    "Ошибка",
                    MessageBoxButtons.OK);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Song currentSong = playlist.playlist[listBox1.SelectedIndex];

            playlist.currentIndex = listBox1.SelectedIndex;

            label5.Text = currentSong.Title;
            label6.Text = currentSong.Author;
            label7.Text = currentSong.FileName;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            playlist.clearPlaylist();

            listBox1.Items.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                playlist.playlist.RemoveAt(listBox1.SelectedIndex);

                listBox1.Items.Clear();

                List<string> songsNames = new List<string>();

                foreach (var song in playlist.playlist)
                {
                    songsNames.Add(song.Title);
                }

                listBox1.Items.AddRange(songsNames.ToArray());

                playlist.currentIndex = 0;

                label5.Text = "";
                label6.Text = "";
                label7.Text = "";
            }
            else
            {
                MessageBox.Show(
                    "Выберите песню!",
                    "Ошибка",
                    MessageBoxButtons.OK);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (playlist.playlist.Count < 1)
            {
                playlistIsEmpty();
            }
            else
            {
                playlist.previousSong();

                listBox1.SelectedIndex = playlist.currentIndex;

                label5.Text = playlist.playlist[playlist.currentIndex].Title.ToString();
                label6.Text = playlist.playlist[playlist.currentIndex].Author.ToString();
                label7.Text = playlist.playlist[playlist.currentIndex].FileName.ToString();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (playlist.playlist.Count < 1)
            {
                playlistIsEmpty();
            }
            else
            {
                playlist.nextSong();

                listBox1.SelectedIndex = playlist.currentIndex;

                label5.Text = playlist.playlist[playlist.currentIndex].Title.ToString();
                label6.Text = playlist.playlist[playlist.currentIndex].Author.ToString();
                label7.Text = playlist.playlist[playlist.currentIndex].FileName.ToString();
            }
        }
    }
}
