﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Shop
{
    class Shop
    {
        public List<Product> products;
        public decimal cash = 0;
        public int currentIndex = 0;

        public Shop()
        {
            products = new List<Product>();
        }

        public void addProduct(Product product)
        {
            products.Add(product);
        }

        public void WriteAllProducts()
        {
            Console.WriteLine("Список продуктов: ");

            foreach (var product in products)
            {
                Console.WriteLine($"Наименование: { product.Name}; Цена: {product.Price} руб. Количество: {product.Count}");
            }
        }

        public void createProduct(string name, decimal price, int count)
        {
            products.Add(new Product(name, price, count));
        }

        public Product findByName(string name)
        {
            foreach (var product in products)
            {
                if (product.Name == name)
                {
                    return product;
                }
            }

            return null;
        }

        public void sell(Product product)
        {
            products.RemoveAt(currentIndex);
        }

        public void getCash()
        {
            Console.WriteLine($"Прибыль магазина составляет: {cash}");
        }

        public void sell(string ProductName)
        {
            Product ToSell = findByName(ProductName);

            if (ToSell != null)
            {
                this.sell(ToSell);
                cash += ToSell.Price;
            }
            else
            {
                Console.WriteLine("Товар не найден!");
            }
        }

        public void sell(string[] productNames)
        {
            foreach (var productName in productNames)
            {
                Product ToSell = findByName(productName);

                if (ToSell != null)
                {
                    this.sell(ToSell);
                }
                else
                {
                    Console.WriteLine("Товар не найден!");
                }
            }
        }
    }
}
