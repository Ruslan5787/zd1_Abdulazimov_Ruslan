﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Shop
{
    public partial class Form1 : Form
    {
        public string checkingString(string text)
        {
            string message = "";

            foreach (var letter in text)
            {
                int num;

                if (!char.IsNumber(letter) || !char.IsLetter(letter))
                {
                    message = "Можно вводить только буквы и цифры!";
                }
            }

            return message;
        }

        public string checkingNumber(string text, string fieldName)
        {
            string message = "";

            if (text == "")
            {
                message = $"Поле {fieldName} пустое";
            }
            foreach (var letter in text)
            {
                int num;

                if (!char.IsNumber(letter))
                {
                    message = $"В поле {fieldName} vожно вводить только цифры!";
                }
            }

            return message;
        }

        Shop pyaterochka = new Shop();

        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && numericUpDown2.Value > 0 && numericUpDown3.Value > 0)
            {
                if (checkingString(textBox1.Text) != "")
                {
                    pyaterochka.createProduct(textBox1.Text, numericUpDown2.Value, Int32.Parse(numericUpDown3.Value.ToString())); 

                    listBox1.Items.Clear();

                    List<string> products = new List<string>();

                    foreach (var product in pyaterochka.products)
                    {
                        products.Add($"Наименование: {product.Name}. Цена: {product.Price} руб. Количество: {product.Count}.");
                    }

                    listBox1.Items.AddRange(products.ToArray());

                    textBox1.Text = "";
                    numericUpDown2.Value = 0;
                    numericUpDown3.Value = 0;
                }
                else
                {
                    MessageBox.Show(
                    "Можно вводить только буквы и цифры!",
                    "Ошибка",
                    MessageBoxButtons.OK);
                }
            }
            else
            {
                MessageBox.Show(
                    "Заполните пустые поля!",
                    "Ошибка",
                    MessageBoxButtons.OK);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                if (numericUpDown1.Value > 0 && numericUpDown1.Value < pyaterochka.products[listBox1.SelectedIndex].Count)
                {
                    pyaterochka.products[listBox1.SelectedIndex].Count -= Int32.Parse(numericUpDown1.Value.ToString());

                    pyaterochka.cash += pyaterochka.products[listBox1.SelectedIndex].Price * numericUpDown1.Value;

                    label6.Text = pyaterochka.cash.ToString();

                    listBox1.Items.Clear();

                    List<string> products = new List<string>();

                    foreach (var product in pyaterochka.products)
                    {
                        products.Add($"Наименование: {product.Name}. Цена: {product.Price} руб. Количество: {product.Count}.");
                    }

                    numericUpDown1.Value = 0;

                    listBox1.Items.AddRange(products.ToArray());
                } else if(numericUpDown1.Value == pyaterochka.products[listBox1.SelectedIndex].Count)
                {
                    pyaterochka.cash += pyaterochka.products[listBox1.SelectedIndex].Price * numericUpDown1.Value;

                    label6.Text = pyaterochka.cash.ToString();

                    pyaterochka.products.RemoveAt(listBox1.SelectedIndex);

                    listBox1.Items.Clear();

                    List<string> products = new List<string>();

                    foreach (var product in pyaterochka.products)
                    {
                        products.Add($"Наименование: {product.Name}. Цена: {product.Price} руб. Количество: {product.Count}.");
                    }

                    numericUpDown1.Value = 0;

                    pyaterochka.currentIndex = 0;
                }
                else
                {
                    MessageBox.Show(
                    "Введите адекватные значения для продажи",
                    "Ошибка",
                    MessageBoxButtons.OK);
                }
            }
            else
            {
                MessageBox.Show(
                    "Выберите продукт!",
                    "Ошибка",
                    MessageBoxButtons.OK);
            }
        }
    }
}
