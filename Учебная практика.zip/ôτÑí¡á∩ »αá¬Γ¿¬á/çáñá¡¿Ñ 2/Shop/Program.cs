﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Shop
{
    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main ()
        {
            Application.EnableVisualStyles( );
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1( ));

            //----------------------------------------------------

            Shop pyaterochka = new Shop( );

            pyaterochka.createProduct("Кола", 85, 200);
            pyaterochka.createProduct(@"Сок\Добрый\", 100, 50);

            pyaterochka.WriteAllProducts( );

            pyaterochka.sell("Кола");

            pyaterochka.getCash();

            pyaterochka.WriteAllProducts();
        }
    }
}
